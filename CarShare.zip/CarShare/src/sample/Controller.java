package sample;

import javafx.event.ActionEvent;

import java.awt.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;
import java.sql.DriverManager;
import java.util.Properties;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;


public class Controller {
    @FXML
    private TextField TableLogin;
    @FXML
    private PasswordField TablePassword;
    @FXML
    private Canvas MoscowMap;

    public void Entering(ActionEvent actionEvent) throws SQLException, IOException {
        Stage primary = (Stage) TableLogin.getScene().getWindow();
        Properties properties = new Properties();
        properties.setProperty("user",TableLogin.getText());
        properties.setProperty("password",TablePassword.getText());
        properties.setProperty("serverTimezone","UTC");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb",properties);
        Scene scene2 = new Scene(FXMLLoader.load(getClass().getResource("scene3.fxml")));
        primary.setScene(scene2);
        StartUse();
        con.close();
    }

    private void StartUse() throws FileNotFoundException {
        Image map = new Image(getClass().getResourceAsStream("moskvaavtomobilnaja.jpg"));
        //Image map = new Image(new FileInputStream("moskvaavtomobilnaja.jpg"));
        GraphicsContext graph = MoscowMap.getGraphicsContext2D();
        graph.drawImage(map,0,0,728,604);
    }

    public void Register(ActionEvent actionEvent) throws IOException {
        Stage primary = (Stage) TableLogin.getScene().getWindow();
        Scene scene2 = new Scene(FXMLLoader.load(getClass().getResource("scene2.fxml")));
        primary.setScene(scene2);
    }
}
